package com.teamp.spring.tp.dto;

import lombok.Data;

@Data
public class ReservationVo {
    private String R_date;
    private String R_name;
    private String R_hospital_name;
}
